package Animal;



public class Rabbit extends Animal {

	public Rabbit(boolean status, int rank, String name) {
		// TODO Auto-generated constructor stub
        this.status=status;
        this.rank=rank;
        this.x=0;
        this.y=0;
        this.name=name;
	}

	@Override
    public void eat(Animal rabbit) {
        System.out.println("我谁也吃不了");
    }
}
