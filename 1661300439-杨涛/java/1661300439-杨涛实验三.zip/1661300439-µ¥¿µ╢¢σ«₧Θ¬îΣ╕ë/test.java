package Animal;


public class test {
    public static void main(String[] args) {
    	Rabbit[] rabbit={ new Rabbit(true,1,"rabbit_0"),
                          new Rabbit(true,1,"rabbit_1"),
                          new Rabbit(true,1,"rabbit_2"),
                          new Rabbit(true,1,"rabbit_3"),
                          new Rabbit(true,1,"rabbit_4"),
                          new Rabbit(true,1,"rabbit_5")};
    	Wolf[] wolf= {    new Wolf(true,2,"wolf_0"),
                          new Wolf(true,2,"wolf_1")};
    	Lion[] lion= {    new Lion(true,3,"lion")};


        Animal[][] animal={lion,wolf,rabbit};


//10 times loop ,let them moving and fighting
        for (int i = 0; i <10; i++) {

            System.out.println("\nthose are animals the  "+i+" times runing \n");
            for (int j = 0; j < animal.length; j++) {
                    for (int z = 0; z < animal[j].length; z++) {
                        animalMove(animal[j][z]);//all of the animals is runing
                    }

            }

//this is gona juadging  weither the rabbit was ate by wolf
            for (int j = 0; j < rabbit.length; j++) {
                for (int k = 0; k < wolf.length; k++) {
                    animalFight(rabbit[j],wolf[k]);
                }
            }

//this is gona juadging  weither the rabbit was ate by lion
            for (int j = 0; j < wolf.length; j++) {
                for (int k = 0; k < lion.length; k++) {
                    animalFight(wolf[j],lion[k]);
                }
            }
        }


        System.out.println("\nthis is display the status of animal:");
            for (int j = 0; j < animal.length; j++) {
                for (int i = 0; i < animal[j].length; i++) {
                    System.out.println(animal[j][i].name +"  : "+animal[j][i].status);
                }
            }
          
        }



    private static void animalFight(Animal animal1,Animal animal2) {
        //动物被吃的条件，该动物能被吃，动物活着， 位置相同
        if (animal1.getStatus()==true&&animal1.rank<animal2.rank&&animal1.getX()==animal2.getX()&&animal1.getY()==animal2.getY()) {
            animal2.eat(animal1);
            System.out.println("\n\n_______________  Oh god!  "+animal1.name+" was  ate by "+animal2.name+"  ____________");
        }
    }



    private static void animalMove( Animal animal) {
        if (animal.getStatus()==true) {
            int animal_x= (int )(Math.random()*10+1);
            int animal_y= (int )(Math.random()*10+1);
            animal.move(animal_x,animal_y);
            System.out.println("("+animal.name+")    location is:   "+animal.getX()+"  :   "+animal.getY());
        }
    }
}
