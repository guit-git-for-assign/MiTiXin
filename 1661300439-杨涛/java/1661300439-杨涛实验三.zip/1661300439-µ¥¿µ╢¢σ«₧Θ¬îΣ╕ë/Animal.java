package Animal;

public  abstract  class Animal {
    protected  String name;
    protected  boolean status;
    protected  int rank;
    protected  int x=0;
    protected  int y=0;

    public  boolean getStatus() {
        return status;
    }

    public  void setStatus(boolean status) {
        this.status = status;
    }

    public  void move(int x,int y) {
        this.x=x;
        this.y=y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public abstract void eat(Animal rabbit);

}
