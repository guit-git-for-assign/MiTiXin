package Animal;


public class Lion extends Animal {
    private Wolf wolf;


    public Lion(boolean status, int rank, String name) {
		// TODO Auto-generated constructor stub
        super.status=status;
        this.rank=rank;
        this.x=0;
        this.y=0;
        this.name=name;
	}

	@Override
    public void eat(Animal wolf) {
        if (wolf.status == true) {
            wolf.setStatus(false);
            wolf.getStatus();
        }else System.out.println("here have some problem ");
    }
}
