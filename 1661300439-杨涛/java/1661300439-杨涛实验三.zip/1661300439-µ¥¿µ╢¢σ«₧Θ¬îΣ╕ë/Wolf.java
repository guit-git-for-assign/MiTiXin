package Animal;


public class Wolf extends Animal {
    public Wolf(boolean status, int rank,String name) {
        this.status=status;
        this.rank=rank;
        this.x=0;
        this.y=0;
        this.name=name;
    }

    @Override
    public void eat(Animal rabbit) {
        if (rabbit.status==true) {
            rabbit.setStatus(false);
            rabbit.getStatus();
        } else System.out.println("鍏斻�傚瓙琚悆鍑虹幇浜嗗紓甯�");
    }

}
