package Animal;


public class Lion extends Animal {
    private Wolf wolf;


    public Lion(boolean status, int rank) {
        super.status=status;
        this.rank=rank;
        this.x=0;
        this.y=0;
    }

    @Override
    public void eat(Animal wolf) {
        if (wolf.status == true) {
            wolf.setStatus(false);
            wolf.getStatus();
        }else System.out.println("狼的被吃出先了异常。");
    }
}
