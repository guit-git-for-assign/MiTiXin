package Animal;

public class test {
    public static void main(String[] args) {
        //初始化出兔子，狼，狮子
        Animal rabbit= new Rabbit(true,1);
        Animal wolf= new Wolf(true,2);
        Animal lion= new Lion(true,3);

        //兔子，狼，狮子，100次 相互残杀的逻辑处理
        for (int i = 0; i <100; i++) {
            //移动 用线程写会好一点
            AnimalMove(rabbit);
            AnimalMove(wolf);
            AnimalMove(lion);
            //（ 兔子活着， 是兔子， 狼抓到兔子了）
            if (rabbit.rank==1&&rabbit.getStatus()==true&&rabbit.getX()==wolf.getX()&&rabbit.getY()==wolf.getY()){
                wolf.eat(rabbit);
                System.out.println("(兔子) 被吃到了");
            }
            // （ 狼活着， 是狼， 狮子抓到狼了）
            if (wolf.rank==2&&wolf.getStatus()==true&&wolf.getX()==lion.getX()&&wolf.getY()==lion.getY()){
                lion.eat(wolf);
                System.out.println("(狼)   被吃到了");
            }
        }


        //打印状态
        System.out.println("兔子的状态：   "+rabbit.status);
        System.out.println("狼的状态：     "+wolf.status);
        System.out.println("狮子的状态：   "+lion.status);


    }

    private static void AnimalMove( Animal animal) {
        if (animal.rank==1&&animal.getStatus()==true){
                int rabiit_x= (int )(Math.random()*10+1);
                int rabiit_y= (int )(Math.random()*10+1);
                animal.move(rabiit_x,rabiit_y);
                System.out.println("兔子移动的位置是:   "+animal.getX()+"  :   "+animal.getY());

        }
        if (animal.rank==2&&animal.getStatus()==true){
            if (animal.rank==2){
                    int wolf_x= (int )(Math.random()*10+1);
                    int wolf_y= (int )(Math.random()*10+1);
                    animal.move(wolf_x,wolf_y);
                    System.out.println("狼移动的位置是:     "+animal.getX()+"  :   "+animal.getY());

            }

        }
        if (animal.rank==3&&animal.getStatus()==true){
            if (animal.rank==3){
                    int lion_x= (int )(Math.random()*10+1);
                    int lion_y= (int )(Math.random()*10+1);
                    animal.move(lion_x,lion_y);
                    System.out.println("狮子移动的位置是:   "+animal.getX()+"  :   "+animal.getY());

            }
        }
    }
}
