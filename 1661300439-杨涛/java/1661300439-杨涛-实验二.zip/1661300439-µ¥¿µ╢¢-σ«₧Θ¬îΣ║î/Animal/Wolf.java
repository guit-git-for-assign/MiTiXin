package Animal;


public class Wolf extends Animal {
//    private Rabbit rabbit;
    public Wolf(boolean status, int rank) {
        this.status=status;
        this.rank=rank;
        this.x=0;
        this.y=0;
    }

    @Override
    public void eat(Animal rabbit) {
        if (rabbit.status==true) {
            rabbit.setStatus(false);
            rabbit.getStatus();
        } else System.out.println("兔。子被吃出现了异常");
    }

}
