package Animal;

import Animal.Animal;

public class Rabbit extends Animal {
    public Rabbit(boolean status, int rank) {
        this.status=status;
        this.rank=rank;
        this.x=0;
        this.y=0;
    }

    @Override
    public void eat(Animal rabbit) {
        System.out.println("我谁也吃不了");
    }
}
