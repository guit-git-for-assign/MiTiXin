package com.wjy;

import java.util.Scanner;

public class Shangdian 
{
	Shangping[] shangpings;

	public Shangdian(Shangping[] shangpings) 
	{
		super();
		this.shangpings = shangpings;
	}
	
	public void showAll()
	{
		for (int i = 0; i < shangpings.length; i++)
		{
			System.out.println("name:"+shangpings[i].getName()+",sal:"+shangpings[i].getSal());
		}
	}
	
	public void select(String zf)
	{
		boolean t = false;
		for (int i = 0; i < shangpings.length; i++)
		{
			if (shangpings[i].getName().contains(zf))
			{
				System.out.println("name:"+shangpings[i].getName()+",sal:"+shangpings[i].getSal());
				t = true;
			}
		}
		
		if (!t)
		{
			System.out.println("û�к��� "+zf+" �ؼ��ֵ��̿�����");
		}
		
	}
	
	public String inString()
	{
		System.out.println("������ؼ���:");
		Scanner in = new Scanner(System.in);
		String zf = in.next();
		return zf;
	}
	
}
