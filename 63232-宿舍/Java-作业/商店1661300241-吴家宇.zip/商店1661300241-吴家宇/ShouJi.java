package com.wjy;

public class ShouJi implements Shangping
{
	String name;
	double sal;
	
	public ShouJi(String name, double sal) {
		super();
		this.name = name;
		this.sal = sal;
	}
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	@Override
	public double getSal() {
		// TODO Auto-generated method stub
		return sal;
	}
}
