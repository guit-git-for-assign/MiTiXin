package com.wjy;

public class DianNao implements Shangping {

	String name;
	double sal;
	
	public DianNao(String name, double sal) {
		super();
		this.name = name;
		this.sal = sal;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public double getSal() {
		// TODO Auto-generated method stub
		return sal;
	}

}
