package com.wjy;

import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) 
	{
		Shangping dianNao1 = new DianNao("��Ϊ����", 5000);
		Shangping dianNao2 = new DianNao("��˶����", 7000);
		
		Shangping shouji1 = new ShouJi("��Ϊ�ֻ�",8000);
		
		Shangping [] shangpings = {dianNao1,dianNao2,shouji1};
		
		Shangdian shangdian = new Shangdian(shangpings);
		
		boolean b = false;
		
		do
		{
			System.out.println("1.��ʾ������Ʒ��Ϣ");
			System.out.println("2.����ؼ��ֲ�����Ʒ��Ϣ");
			System.out.println("0.����");
			
			Scanner in = new Scanner(System.in);
			int i = in.nextInt();
			
			switch (i) {
			case 1:
				shangdian.showAll();
				System.out.println("-----------------");
				break;
			case 2:
				String zf = shangdian.inString();	
				shangdian.select(zf);
				break;
			case 0:
				b = true;
			}
			
			
		}while(!b);
		
	}

}
