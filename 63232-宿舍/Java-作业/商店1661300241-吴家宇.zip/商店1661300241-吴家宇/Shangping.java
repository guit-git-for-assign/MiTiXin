package com.wjy;

public interface Shangping 
{
	String getName();
	double getSal();
}
