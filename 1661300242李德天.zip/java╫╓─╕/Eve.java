import java.util.Scanner;
public class Eve {
	public static void main(String[] args){
		Scanner input=new Scanner(System.in);
		System.out.print("����һ���ַ�: ");
		String s=input.nextLine();
		int[] counts=countLetters(s.toLowerCase());
		for(int i=0;i<counts.length;i++){
			if(counts[i]!=0)
				System.out.println((char)('a'+i)+" ���� "+counts[i]+((counts[i]==1)?"��":"��"));
		}
	}
	public static int[] countLetters(String s){
		int[] counts=new int[26];
		for(int i=0;i<s.length();i++){
			if(Character.isLetter(s.charAt(i)))
				counts[s.charAt(i)-'a']++;
		}
		return counts;
	}
 
}