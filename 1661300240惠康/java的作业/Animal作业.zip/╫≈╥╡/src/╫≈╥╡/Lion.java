package ��ҵ;

public class Lion extends Animal {

    public String toString() {
        return "Lion{" +
                "data=" + data +
                ", abscissa=" + abscissa +
                ", ordinate=" + ordinate +
                '}';
    }
}
