package ��ҵ;

public class Wolf extends Animal {

    
    public String toString() {
        return "Wolf{" +
                "data=" + data +
                ", abscissa=" + abscissa +
                ", ordinate=" + ordinate +
                '}';
    }
}