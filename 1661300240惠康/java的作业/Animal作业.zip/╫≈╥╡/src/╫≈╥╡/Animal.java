package ��ҵ;

public class Animal {
    //��ǰ������
    public int abscissa;
    public int data;
    public String name;
    //������
    public int ordinate;

    public void setData(int data) {
        this.data = data;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void set(int abscissa, int ordinate){
        this.abscissa=abscissa;
        this.ordinate=ordinate;
    }

    public String toString() {
        return "Animal{" +
                "abscissa=" + abscissa +
                ", data=" + data +
                ", ordinate=" + ordinate +
                '}';
    }
}
