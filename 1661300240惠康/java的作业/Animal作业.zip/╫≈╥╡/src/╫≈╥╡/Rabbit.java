package ��ҵ;

public class Rabbit extends Animal {

    
    public String toString() {
        return "Rabbit{" +
                "data=" + data +
                ", abscissa=" + abscissa +
                ", ordinate=" + ordinate +
                '}';
    }
}